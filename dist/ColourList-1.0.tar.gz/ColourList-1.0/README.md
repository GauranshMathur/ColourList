# ColourList 
This is a colour list python module that you can use to create colourfull websites. Also you can add your own favorite colours
to make the module more customoised to yourself.

## Getting started
You can download the module in itself and use it as that currently. The pip install will be available soon.


